<?php
require_once 'app/helpers.php';
start_session('mblogsession');
$title = 'About'
?>


<?php include 'tpl/header.php';
?>
<main>
  <div class="container mt-5">
    <div class="row addpost">
      <div class="col-12 pt-3 m-auto">
        <h1> MUSIC MSUIC THAT MUSIC MUSIC</h1>
        <h2>THAT MUSIC BLOG!<br> This is the place where you can post your favorite music<br>
          Let evryone know what Music do you dig!</h2>
      </div>
    </div>

</main>
<?php include 'tpl/footer.php';?>