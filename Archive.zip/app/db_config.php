<?php
define('MYSQL_HOST', 'localhost');
define('MYSQL_USER', 'mblog');
define('MYSQL_PWD', 'mblog');
define('MYSQL_DB', 'musicblog');

$mysql_link = null;